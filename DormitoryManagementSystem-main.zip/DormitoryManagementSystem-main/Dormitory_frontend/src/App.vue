<template>
    <div class="app" v-title title="宿舍管理系统"></div>
  <div>
    <router-view/>
  </div>
</template>

<style>

</style>

<script>


export default {
  name: "Layout",
}
</script>
