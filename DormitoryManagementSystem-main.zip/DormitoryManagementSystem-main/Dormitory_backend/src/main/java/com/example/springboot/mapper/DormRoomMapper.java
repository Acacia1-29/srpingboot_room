package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.DormRoom;


public interface DormRoomMapper extends BaseMapper<DormRoom> {

}
