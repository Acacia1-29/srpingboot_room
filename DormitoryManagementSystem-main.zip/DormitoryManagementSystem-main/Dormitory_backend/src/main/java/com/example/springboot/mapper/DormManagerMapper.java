package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.DormManager;


public interface DormManagerMapper extends BaseMapper<DormManager> {
}
