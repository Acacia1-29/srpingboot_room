package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.Repair;

public interface RepairMapper extends BaseMapper<Repair> {
}
