package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.Admin;


public interface AdminMapper extends BaseMapper<Admin> {
}
